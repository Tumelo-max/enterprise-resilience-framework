# PP4: Solutions Design
### Strategies and Solutions — Meridian Fulfilment Co.

This document specifies how Meridian will actually meet the business
continuity requirements identified in PP3 (Analysis). It distinguishes
between **strategies** (the high-level approach) and **solutions** (how
each strategy is actually delivered) — a distinction that matters because
one strategy can be delivered by more than one solution, and a single
solution can support more than one strategy.

---

## 1. Strategy 1: Maintain Minimum Viable Operations During WMS Outage

**Objective this strategy meets:** MBCO of 60% picking throughput within
the 4-hour RTO (from the BIA).

**Solutions:**
- Manual fallback procedure using pre-printed pick lists generated from
  the last known-good inventory snapshot (see PP5, `manual-failover-procedures.md`)
- Pre-staged fallback kits at each DC (paper templates, carrier portal
  credentials, offline reference copies of playbooks)
- Cross-trained floor staff capable of executing manual picking without
  live WMS guidance

**Cost consideration:** Low ongoing cost (printing, periodic kit
refreshes); primary investment is staff training time, weighed against the
severe financial impact of unmitigated downtime identified in the BIA.

---

## 2. Strategy 2: Prevent Data Loss Beyond the Recovery Point Objective

**Objective this strategy meets:** RPO of 15 minutes (from the BIA).

**Solutions:**
- Automated inventory and transaction snapshots every 15 minutes
- Manual transaction logs during fallback mode, reconciled against the
  system of record once the WMS is restored (see PP5, reconciliation
  steps)

**Cost consideration:** Snapshot automation is a low-cost, one-time
engineering investment relative to the severe consequence (from the Risk
Assessment) of undetected data corruption.

---

## 3. Strategy 3: Reduce Likelihood of Vendor-Introduced Outages

**Objective this strategy meets:** Risk treatment for "failed WMS vendor
patch" (from the Risk Assessment).

**Solutions:**
- Staged patch rollout requiring IT sign-off before production deployment
- Rollback procedure documented and tested as part of the validation
  programme (PP6)

**Cost consideration:** Adds modest process overhead to vendor patch
cycles, justified against the high consequence rating this risk carries.

---

## 4. Strategy 4: Reduce Single Points of Failure in Key Personnel Knowledge

**Objective this strategy meets:** Risk treatment for "loss of key WMS
personnel" (from the Risk Assessment).

**Solutions:**
- Minimum two staff per DC cross-trained on WMS administration
- Configuration and governance knowledge documented centrally (PP1)
  rather than held only in individuals' heads

**Cost consideration:** Training time investment, but directly closes a
Medium-rated risk identified in PP3 at relatively low ongoing cost.

---

## 5. How Strategies Map to Solutions (Summary)

| Strategy | Primary Solution(s) | Meets Requirement |
|---|---|---|
| Minimum viable operations during outage | Manual fallback + fallback kits | MBCO (60%), RTO (4 hrs) |
| Prevent data loss | Automated snapshots + manual reconciliation | RPO (15 min) |
| Reduce vendor-introduced outage risk | Staged patch rollout + rollback plan | Risk treatment (vendor patch) |
| Reduce key-person risk | Cross-training + central documentation | Risk treatment (key personnel) |

---

## 6. Next Step: Enabling These Solutions

This document defines *what* Meridian will do. **PP5 (Enabling Solutions)**
turns these agreed solutions into the actual response structure and
operational playbooks that DC teams execute during a real disruption.
