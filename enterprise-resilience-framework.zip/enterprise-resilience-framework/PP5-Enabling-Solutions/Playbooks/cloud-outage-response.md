# Playbook: Regional Cloud Infrastructure Outage

**Scenario:** The cloud provider hosting the WMS platform for a regional
distribution centre experiences a service disruption, taking the WMS
offline for that region.

**Roles referenced below are defined in** `../Response-Structure.md`.

---

## 1. Detection & Invocation

- [ ] Monitoring/alerting flags WMS unavailability (automated) or DC
      Operations Lead reports system down (manual)
- [ ] Incident Commander confirms outage scope: single region vs.
      multi-region
- [ ] If restoration isn't expected within 30 minutes, Incident Commander
      formally **invokes** the BC arrangements (see `Response-Structure.md`,
      Section 2) — incident channel opened, communication tree activated

## 2. Immediate Response (0–30 minutes)

- [ ] Confirm whether this is a cloud provider outage (check provider
      status page) or an internal fault
- [ ] Notify affected DC Operations Lead to prepare for manual fallback
      (`manual-failover-procedures.md`)
- [ ] IT/Platform Lead opens communication line with cloud provider
      support (if applicable)

## 3. Stabilisation (30 minutes – 4 hours / RTO)

- [ ] DC transitions to manual fallback if WMS not restored within 30
      minutes
- [ ] Track elapsed time against the 4-hour RTO defined in the BIA
      (`PP3-Analysis/Business-Impact-Analysis.md`)
- [ ] Hourly status updates per the severity-level escalation in
      `Response-Structure.md`
- [ ] Log all actions and timestamps for the post-incident review (PP6)

## 4. Recovery

- [ ] Validate WMS functionality before resuming automated operations
- [ ] Reconcile manually logged transactions and inventory movements
      against the system of record
- [ ] Confirm no data loss beyond the 15-minute RPO
- [ ] Formally close the incident once full operations are confirmed
      stable

## 5. Post-Incident

- [ ] Post-incident review within 5 business days, per the validation
      programme (`PP6-Validation/Exercise-and-Testing-Programme.md`)
- [ ] Root cause documented
- [ ] Update this playbook with lessons learned
- [ ] Report incident summary to the Resilience Steering Committee
