# Playbook: Manual Failover Procedures

**Purpose:** Maintain the Minimum Business Continuity Objective (60%
picking throughput) when the WMS is unavailable, until automated systems
are restored.

**Roles referenced below are defined in** `../Response-Structure.md`.

---

## Trigger

WMS unavailable for **more than 30 minutes** and BC arrangements formally
**invoked**, per `cloud-outage-response.md`.

## 1. Activation

- [ ] DC Operations Lead activates the manual fallback procedure
- [ ] BC Champion retrieves the DC's fallback kit and distributes
      pre-printed pick lists, generated from the last known-good
      inventory snapshot (15-minute automated snapshot — see
      `PP4-Solutions-Design/Strategies-and-Solutions.md`, Strategy 2)
- [ ] DC Operations Lead notifies warehouse floor staff of manual mode
      activation

## 2. Manual Picking & Packing

- [ ] Pickers use paper pick lists instead of automated pick-path
      guidance
- [ ] All picks logged manually on tracking sheets (item, quantity, order
      ID, timestamp)
- [ ] Packing proceeds as normal; packing slips generated from
      pre-printed templates if the label system is also affected

## 3. Manual Shipping

- [ ] If the carrier API integration is down, use carrier web portals
      directly for label generation (fallback account credentials are
      part of the DC's fallback kit)
- [ ] Log all dispatched shipments manually for later reconciliation

## 4. Data Reconciliation (on WMS restoration)

- [ ] All manually logged picks, packs, and shipments entered into the
      WMS once restored
- [ ] Cross-check manual logs against WMS inventory to identify
      discrepancies
- [ ] Flag and investigate any mismatches before resuming full automated
      operations — this closes the loop on the RPO commitment from the
      BIA

## 5. Standing Requirements

- [ ] Each DC maintains an updated **fallback kit**: pre-printed pick
      list templates, packing slip templates, carrier portal login
      details, and a physical copy of this playbook
- [ ] Fallback kit contents reviewed monthly as part of the DC Readiness
      Check-in (see `PP2-Embracing-Business-Continuity/BC-Culture-and-Embedding.md`)
      and tested formally as part of the validation programme (PP6)

---

*This procedure prioritises maintaining the agreed Minimum Business
Continuity Objective over matching normal-operations throughput — the
goal during fallback is zero data loss and accurate reconciliation, not
speed.*
