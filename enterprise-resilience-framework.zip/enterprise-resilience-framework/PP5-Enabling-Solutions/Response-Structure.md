# PP5: Enabling Solutions
### Response Structure — Meridian Fulfilment Co.

Once solutions are designed and agreed (PP4), they need to be
operationalised: implemented, supported by a defined response structure,
and documented as BC plans that response teams actually follow. This
document defines the response structure; the detailed operational plans
themselves live in `Playbooks/`.

---

## 1. Response Roles

| Role | Responsibility | Activated When |
|---|---|---|
| **Incident Commander** | Overall incident coordination, declares invocation, owns communication to the Resilience Steering Committee | Any confirmed WMS disruption |
| **DC Operations Lead** | Executes manual fallback procedures on the DC floor | Local disruption or invocation instruction |
| **BC Champion** | Supports fallback kit deployment, liaises between floor staff and Incident Commander | Any DC-level disruption |
| **IT/Platform Lead** | Diagnoses root cause, liaises with cloud provider or WMS vendor, confirms restoration | Any technical disruption |
| **Client Success Lead** | Manages external/client-facing communication | Disruption affecting client-facing SLAs (per BIA impact timeline) |

---

## 2. Invocation

**Invocation** is the formal act of declaring that Meridian's BC
arrangements need to be put into effect. For this BCMS, invocation is
declared by the Incident Commander once:

1. WMS unavailability is confirmed (not a brief blip — sustained beyond
   initial triage), **and**
2. Restoration is not expected within 30 minutes.

Invocation triggers the manual fallback procedure (see
`Playbooks/manual-failover-procedures.md`) and activates the communication
tree below.

---

## 3. Communication Tree

```
Incident Commander
    ├── DC Operations Leads (all 3 DCs) — fallback activation instruction
    ├── IT/Platform Lead — root cause investigation
    ├── Client Success Lead — external communication, if client SLAs at risk
    └── Resilience Steering Committee — status updates per severity level
```

---

## 4. Severity Levels and Escalation

| Severity | Definition | Escalation |
|---|---|---|
| **Low** | Single DC, <2 hours, no client impact | Incident Commander + DC Lead only |
| **Medium** | Single DC, 2–8 hours, or minor client SLA risk | + IT/Platform Lead, Client Success Lead notified |
| **High** | Multi-DC, or approaching MTPD (24 hrs) | + Full Resilience Steering Committee, hourly updates |

---

## 5. From Response Structure to Operational Plans

This document defines *who* responds and *how they're organised*. The
detailed, step-by-step operational plans each role actually follows during
a disruption are in:

- [`Playbooks/cloud-outage-response.md`](Playbooks/cloud-outage-response.md)
  — the Incident Commander and IT/Platform Lead's tactical guide
- [`Playbooks/manual-failover-procedures.md`](Playbooks/manual-failover-procedures.md)
  — the DC Operations Lead and BC Champion's tactical guide

These plans are scalable by design — built to be usable regardless of
which specific incident triggers them, not hard-coded to one exact
failure scenario.
