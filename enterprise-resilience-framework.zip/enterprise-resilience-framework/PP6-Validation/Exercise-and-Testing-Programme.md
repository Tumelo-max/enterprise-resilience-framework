# PP6: Validation
### Exercise and Testing Programme — Meridian Fulfilment Co.

A BCMS cannot be considered reliable until it's actually been exercised.
No matter how well-designed a solution or playbook appears on paper,
realistic exercises are what surface the gaps that assumptions alone
miss. This document defines how Meridian validates that its BCMS
genuinely works — through exercising, maintenance, and review.

---

## 1. Exercising

Exercising is the process of training for, assessing, and improving
organisational performance against the BCMS. Meridian uses a graduated
approach — increasing realism as confidence in the plans grows.

| Exercise Type | Description | Frequency |
|---|---|---|
| **Tabletop exercise** | Discussion-based walkthrough of a scenario (e.g., "the cloud provider hosting DC-2 has an outage — walk through your response") with DC leads, IT, and BC Champions, without executing live changes | Quarterly |
| **Partial failover test** | Live test of the manual fallback procedure during a scheduled low-traffic window — real pick lists printed and worked, real reconciliation performed | Bi-annual |
| **Full failover test** | Complete simulated regional outage and recovery, run as close to a real invocation as safely possible | Annual |

### Example Tabletop Scenario

A tabletop exercise is driven by a pre-planned scenario and a series of
**injects** — timed events introduced during the exercise to test
decision-making under evolving conditions. Example inject sequence for a
Q3 tabletop:

1. **Inject 1 (T+0):** "DC-2's WMS access has been unresponsive for 10
   minutes." → Participants decide: monitor, or begin invocation prep?
2. **Inject 2 (T+25 min):** "Cloud provider status page confirms a
   regional outage, no ETA." → Participants decide: invoke now?
3. **Inject 3 (T+2 hrs):** "A major client is asking why their order
   hasn't shipped." → Tests the Client Success Lead's escalation response
4. **Inject 4 (T+5 hrs):** "WMS restored — reconciliation begins." →
   Tests the data reconciliation steps in `manual-failover-procedures.md`

---

## 2. Maintenance

Maintenance ensures Meridian's BC arrangements and plans remain relevant
and operationally ready — not a one-time artefact that quietly goes stale.

| Maintenance Activity | Frequency | Owner |
|---|---|---|
| Fallback kit content check | Monthly | BC Champion (per DC) |
| Playbook accuracy review | Quarterly, or after any real incident | BC Programme Owner |
| BIA and Risk Assessment refresh | Annually, or after material operational change | BC Programme Owner + Resilience Steering Committee |
| Contact list / escalation tree accuracy | Quarterly | Incident Commander |

---

## 3. Review

Review assesses the ongoing suitability, adequacy, and effectiveness of
the whole BCMS — not just whether individual plans are current, but
whether the *system as a whole* still fits how Meridian actually operates.

**Every exercise and real incident produces a formal review**, covering:
- What worked as planned
- What didn't, and why
- Specific playbook, governance, or training updates required
- Whether findings point to a need to revisit the BIA or Risk Assessment
  (PP3) — e.g., if an exercise reveals a dependency that wasn't captured
  originally

Reviews are approached with a positive, improvement-oriented mindset —
gaps found during a tabletop exercise are treated as the exercise doing
its job, not as failures.

---

## 4. Closing the Loop

Validation findings feed directly back into the rest of this framework:

```
Exercise / Real Incident
        │
        ▼
   Formal Review (this document)
        │
        ├──► Playbook updates (PP5)
        ├──► Risk Assessment updates (PP3)
        ├──► Governance/training updates (PP1, PP2)
        └──► Reported to Resilience Steering Committee
```

This closes the cycle: Establish (PP1) → Embrace (PP2) → Analyse (PP3) →
Design (PP4) → Enable (PP5) → Validate (PP6) → back into continual
improvement of all six.
