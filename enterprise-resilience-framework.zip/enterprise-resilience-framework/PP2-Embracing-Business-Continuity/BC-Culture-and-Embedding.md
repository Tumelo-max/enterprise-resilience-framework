# PP2: Embracing Business Continuity
### BC Culture and Embedding — Meridian Fulfilment Co.

A BCMS that exists only as a policy document fails the moment it's
actually needed. This document sets out how business continuity becomes
embedded into how Meridian's DC teams actually work — not just something
written down and forgotten.

---

## 1. Why Embedding Matters More Than the Policy Itself

A policy mandates business continuity. **Embedding** is what makes it
real: allocating roles and responsibilities, training people, scheduling
BC-related activities into the normal operating calendar, and building
genuine understanding — not just compliance — across the workforce.

Experience across the industry shows that policy and embedding alone
don't guarantee a fit-for-purpose BCMS. Common failure patterns include:

| Failure Pattern | What It Looks Like at Meridian |
|---|---|
| Insufficient priority | BC readiness checks get pushed back for "more urgent" operational work |
| Lack of ownership | Playbooks are written once by a consultant and never touched again |
| Low attention to detail | A playbook says *what* to do but not precisely *how* — e.g., "switch to manual mode" without a printed pick-list template ready |
| Corners cut | Fallback kits (see PP5) go unchecked for months; BIA data goes stale |
| No learning loop | Tabletop exercises happen but findings are never fed back into the playbooks |

This project's governance structure (PP1, Section 6) and testing cadence
(PP6) are deliberately designed to counter each of these patterns directly.

---

## 2. Roles That Embed BC Into Day-to-Day Operations

- **DC Business Continuity Champions** (introduced in PP1): one per
  distribution centre, responsible for keeping local fallback kits
  current, participating in tabletop exercises, and acting as the first
  point of contact if a disruption occurs on their shift.
- **DC Operations Leads**: responsible for ensuring floor staff know
  where the fallback kit is and what manual mode looks like — not just
  that a policy exists.
- **BC Programme Owner**: runs a recurring awareness cadence (see below)
  so BC isn't something people only think about once a year.

---

## 3. Awareness and Training Cadence

| Activity | Frequency | Audience |
|---|---|---|
| BC awareness briefing | New starter onboarding | All DC floor staff |
| Fallback procedure refresher | Quarterly | DC operations staff |
| Tabletop exercise participation | Quarterly (see PP6) | DC leads, IT, BC Champions |
| Governance and policy review | Annually | Resilience Steering Committee |

---

## 4. Building Genuine Understanding, Not Just Compliance

Training that only explains *what* the policy requires produces
compliance, not resilience. Meridian's approach ties BC training directly
to the DC teams' own operational language and risks:

- Fallback drills are framed around **"what happens to today's orders if
  the system goes dark right now"** — immediate and concrete, not abstract
  policy language.
- BC Champions are drawn from experienced floor staff, not assigned as an
  extra administrative burden to whoever has spare capacity — this builds
  genuine ownership rather than resentment toward "one more compliance
  task."
- Lessons from every tabletop exercise and real incident are fed back
  into both the playbooks (PP5) and this embedding approach itself — if
  people aren't engaging with training, that's treated as a finding to
  investigate, not just a box to re-tick next quarter.

---

## 5. Signals That Embedding Is Working

- DC Champions can describe the fallback procedure from memory, not by
  reading it off a laminated sheet for the first time during a drill.
- Fallback kits are found current and complete during unannounced spot
  checks, not just before scheduled audits.
- Staff raise BC-relevant risks proactively (e.g., "we should update the
  playbook, our carrier changed their portal login process") rather than
  only engaging when prompted.
