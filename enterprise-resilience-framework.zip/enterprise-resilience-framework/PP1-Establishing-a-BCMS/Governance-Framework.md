# PP1: Establishing a BCMS
### Governance Framework — Meridian Fulfilment Co.

This document defines how Meridian's Business Continuity Management
System (BCMS) is scoped, governed, and set up to operate — the foundation
that every other Professional Practice in this project builds on.

---

## 1. Scope of the BCMS

**In scope:** The Warehouse Management System (WMS) platform and the
critical fulfilment functions it supports across Meridian's three regional
distribution centres (DCs) — receiving, inventory management, picking and
packing, outbound shipping, and the financial reconciliation processes tied
to fulfilment.

**Out of scope:** Corporate HR systems, marketing platforms, and IT
infrastructure unrelated to fulfilment operations.

**Interested parties considered in scope:** DC operations staff, IT and
platform teams, carrier and logistics partners, finance, client-facing
account teams, and end clients whose orders depend on the WMS.

---

## 2. Business Continuity Policy (Summary)

Meridian is committed to maintaining the continuity of its fulfilment
operations at a predefined minimum capacity, within acceptable time
frames, during any disruption to the WMS platform or the distribution
centres it serves. This policy is owned by the Resilience Steering
Committee (see Section 3) and reviewed annually or following any material
change to operations, technology, or supplier arrangements.

---

## 3. High-Level Governance

| Body | Composition | Responsibility |
|---|---|---|
| **Resilience Steering Committee** | COO (sponsor), Head of IT, Head of Operations, Finance representative | Owns the BC policy, approves budget and resourcing, reviews programme status quarterly |
| **BC Programme Owner** | Designated resilience lead | Day-to-day ownership of the BCMS; coordinates across PP1–PP6 activities |
| **DC Business Continuity Champions** | One per distribution centre | Support the BCMS from an operational perspective; maintain local documentation and readiness (see PP2) |

---

## 4. BCMS Objectives

The objectives of this BCMS — developed in detail through the Analysis
Professional Practice (PP3) — are to ensure that, in the event of a
disruption to the WMS:

1. Critical fulfilment functions can be resumed within their defined
   Recovery Time Objectives (RTOs).
2. Data integrity is maintained within the defined Recovery Point
   Objective (RPO).
3. Operations can continue at, or above, the Minimum Business Continuity
   Objective (MBCO) for each prioritised activity.
4. Interested parties are kept informed throughout any disruption.

---

## 5. How the BCMS Fits Together

This governance framework sets scope and policy. The remaining
Professional Practices build on it in sequence:

- **PP3 (Analysis)** determines the BCMS's actual objectives — the specific
  RTOs, RPOs, and MBCOs — through the BIA and Risk Assessment.
- **PP4 (Solutions Design)** determines how those objectives will be met.
- **PP5 (Enabling Solutions)** turns agreed solutions into operational
  response plans and structures.
- **PP6 (Validation)** confirms the whole system actually works, and keeps
  it that way over time.
- **PP2 (Embracing Business Continuity)** runs alongside all of the above —
  it's the ongoing work of making sure the BCMS is a living part of how
  Meridian operates, not a document that sits unused until an incident
  forces it open.

---

## 6. Monitoring and Review

The BC policy and this governance framework are reviewed:
- **Annually**, as a standing item for the Resilience Steering Committee
- **Following any material change** — new DC, new WMS vendor, significant
  organisational restructuring, or a real incident that exposes a gap
- **Following each validation exercise** (PP6), where findings may trigger
  a governance-level review, not just a playbook update

None of the activities in this BCMS are one-time exercises. Establishing
and operating it is an iterative process — some elements (like this
governance review) happen infrequently, others (like DC readiness checks)
happen monthly.
