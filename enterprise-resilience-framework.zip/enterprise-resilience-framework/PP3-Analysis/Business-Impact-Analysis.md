# PP3: Analysis
### Business Impact Analysis (BIA) — Meridian Fulfilment Co.

*Simulated BIA for portfolio/demonstration purposes, structured against
ISO 22301-aligned BIA methodology.*

The BIA analyses the impact of disruption over time to determine
Meridian's response, recovery priorities, and resource requirements — in
other words, its business continuity requirements. It is the foundation
for the strategies and solutions designed in PP4.

---

## 1. Purpose & Scope

This BIA identifies critical business functions dependent on the WMS
platform, quantifies the impact of disruption over time, and establishes
recovery priorities and targets for Meridian's interested parties.

**In scope:** WMS platform, regional distribution centre (DC) operations,
inventory data, shipping/carrier integrations, financial transaction
processing tied to fulfilment.

**Out of scope:** Corporate HR systems, marketing platforms, non-fulfilment
IT infrastructure.

---

## 2. Prioritised Activities

| Prioritised Activity | Description | Dependency on WMS |
|---|---|---|
| Inbound receiving | Scanning and logging incoming stock | High |
| Inventory management | Real-time stock levels across 3 DCs | Critical |
| Order picking & packing | Automated pick-path generation | Critical |
| Outbound shipping | Carrier label generation, dispatch scheduling | Critical |
| Returns processing | Reverse logistics intake | Medium |
| Financial reconciliation | Transaction matching for fulfilled orders | High |

---

## 3. Impact Over Time

| Time Since Disruption | Operational Impact | Financial Impact (illustrative) | Impact on Interested Parties |
|---|---|---|---|
| 0–2 hours | Minor delay; queued orders | Negligible | None |
| 2–8 hours | Manual fallback required; picking slows ~60% | Moderate — SLA penalties begin | Low |
| 8–24 hours | Significant backlog; possible missed same-day dispatch | High — carrier SLA breaches, client penalties | Moderate — client escalations |
| 24–72 hours | Regional DC effectively non-operational for automated flow | Severe — lost sales, contractual penalties | High — public-facing delivery delays |
| 72+ hours | Multi-DC cascading backlog | Critical — potential client contract risk | Severe |

---

## 4. Business Continuity Requirements

These figures define the timeframes, resources, and capabilities Meridian
needs to continue delivering its prioritised activities following a
disruption — the actual outputs of this BIA that feed directly into PP4
(Solutions Design):

- **Maximum Tolerable Period of Disruption (MTPD):** 24 hours — beyond
  this point, impacts to contractual and client relationships become
  unacceptable.
- **Recovery Time Objective (RTO):** 4 hours for core WMS functions
  (picking, shipping) — the target timeframe for resuming these activities
  at a minimum acceptable capacity.
- **Recovery Point Objective (RPO):** 15 minutes of inventory/transaction
  data — the acceptable data loss window.
- **Minimum Business Continuity Objective (MBCO):** 60% of standard daily
  picking throughput, sustained via manual fallback procedures, is the
  minimum acceptable capacity during disruption.

---

## 5. Dependencies and Priority Suppliers

- **Internal:** Network infrastructure team, DC operations leads, IT/DevOps
- **Priority suppliers** (those whose failure would have the greatest
  impact on Meridian's ability to deliver its own services):
  - Cloud infrastructure provider hosting the WMS
  - WMS software vendor (support and patching)
  - Primary carrier integration partners

---

## 6. Assumptions & Limitations

This BIA is a simulated exercise built for portfolio demonstration.
Impact figures and recovery targets are illustrative, not derived from
real financial or operational data. A real BIA would be built from actual
interested-party interviews, historical incident data, and financial
records, and would typically be conducted alongside the Risk Assessment
(see `Risk-Assessment.md`) rather than in isolation.
