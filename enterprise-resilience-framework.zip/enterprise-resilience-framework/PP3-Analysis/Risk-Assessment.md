# PP3: Analysis
### Risk Assessment (RA) — Meridian Fulfilment Co.

*Simulated Risk Assessment for portfolio/demonstration purposes, aligned
to ISO 31000 risk management principles.*

Where the BIA (`Business-Impact-Analysis.md`) defines *what happens* if a
prioritised activity is disrupted, the Risk Assessment identifies the
disruption risks to those activities and the resources they depend on —
in other words, *what's likely to cause* the disruption in the first
place. Together, the BIA and RA form the complete Analysis Professional
Practice and feed directly into Solutions Design (PP4).

---

## 1. Risk Identification

Risks are identified against each critical resource supporting the
prioritised activities defined in the BIA.

| Risk Source | Threat | Affected Prioritised Activity |
|---|---|---|
| Cloud infrastructure provider | Regional outage or service degradation | Inventory management, picking, shipping |
| WMS software vendor | Failed patch/update causing platform instability | All WMS-dependent activities |
| Carrier API integration | Third-party API downtime or breaking changes | Outbound shipping |
| Network connectivity (DC-level) | Local ISP or internal network failure | All DC-level WMS access |
| Key personnel | Loss of sole WMS administrator knowledge | Platform configuration, incident response |
| Data integrity | Corrupted inventory sync during a partial outage | Inventory management, financial reconciliation |

---

## 2. Risk Analysis and Evaluation

Each risk is analysed for likelihood and consequence, consistent with
ISO 31000 risk assessment principles — risk assessment should be
conducted systematically and collaboratively, drawing on the knowledge of
interested parties across IT, DC operations, and vendor management.

| Risk | Likelihood | Consequence | Risk Rating |
|---|---|---|---|
| Cloud provider regional outage | Low | Severe | High |
| Failed WMS vendor patch | Medium | High | High |
| Carrier API downtime | Medium | Moderate | Medium |
| DC-level network failure | Medium | Moderate | Medium |
| Loss of key WMS personnel | Low | High | Medium |
| Data corruption during partial outage | Low | Severe | Medium |

---

## 3. Risk Treatment

Consistent with ISO 22300 risk treatment principles, each identified risk
is addressed through one or more treatment approaches: avoiding,
reducing likelihood, reducing consequence, sharing (e.g., via contracts),
or retaining by informed choice.

| Risk | Treatment Approach |
|---|---|
| Cloud provider regional outage | **Reduce consequence** — manual fallback procedures (PP5) cap the operational impact regardless of outage duration |
| Failed WMS vendor patch | **Reduce likelihood** — require staged rollout and sign-off from IT before vendor patches apply to production |
| Carrier API downtime | **Share** — contractual SLA with carrier; **reduce consequence** — manual carrier portal fallback documented in playbooks |
| DC-level network failure | **Reduce consequence** — secondary network connection at each DC (redundancy) |
| Loss of key WMS personnel | **Reduce likelihood** — cross-train at least two staff per DC on WMS administration; document configuration in `PP1-Establishing-a-BCMS` |
| Data corruption during partial outage | **Reduce consequence** — 15-minute automated inventory snapshots (supports the BIA's RPO target directly) |

---

## 4. Relationship to Solutions Design

The risk treatments identified here are inputs to PP4 (Solutions Design) —
this Risk Assessment identifies *what needs mitigating*; PP4 defines the
actual strategies and solutions that deliver that mitigation in practice.

---

## 5. Assumptions & Limitations

This Risk Assessment is a simulated exercise for portfolio demonstration.
Likelihood and consequence ratings are illustrative. A real risk
assessment would draw on actual incident history, vendor SLA data, and
structured input from IT, operations, and vendor management stakeholders.
