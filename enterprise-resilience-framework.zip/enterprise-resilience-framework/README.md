# Enterprise Resilience Framework

A self-directed portfolio project demonstrating business continuity and
organisational resilience practice, structured around the **six Professional
Practices (PPs)** defined by the Business Continuity Institute's Good
Practice Guidelines (GPG) — the framework underpinning the CBCI
(Certificate of the BCI) qualification.

## Why this project exists

This project extends my existing AI governance work (ISO 42001 and NIST AI
RMF frameworks, applied in `llm-vulnerability-assessment` and
`soc-dashboard-mcp-server`) into operational resilience — the discipline of
keeping a business running through disruption, not just governing systems
responsibly.

I built this while preparing for the CBCI qualification, using the BCI's
own Good Practice Guidelines (Lite Edition 7.0) to structure the project
against the real professional framework rather than an informal approach.

**This is a self-directed learning and demonstration project — not a claim
of formal BCM certification, audit experience, or a real client engagement.**
Content and terminology are original, informed by publicly available BCI
and ISO 22301 concepts; the source guide itself is copyrighted by the BCI
and is not reproduced here. See [thebci.org](https://www.thebci.org) for
the official Good Practice Guidelines.

## The Scenario

A simulated mid-size multinational e-commerce / third-party logistics (3PL)
company, **Meridian Fulfilment Co.**, is rolling out a new automated
Warehouse Management System (WMS) across three regional distribution
centres (DCs). This project models how the business identifies, plans for,
governs, and responds to disruption of that system and the operations it
supports.

## Structure — Mapped to the Six Professional Practices

| PP | Professional Practice | What's Inside |
|---|---|---|
| **PP1** | Establishing a BCMS | [`Governance-Framework.md`](PP1-Establishing-a-BCMS/Governance-Framework.md) — scope, policy, high-level governance |
| **PP2** | Embracing Business Continuity | [`BC-Culture-and-Embedding.md`](PP2-Embracing-Business-Continuity/BC-Culture-and-Embedding.md) — how BC becomes part of business-as-usual, not just a policy document |
| **PP3** | Analysis | [`Business-Impact-Analysis.md`](PP3-Analysis/Business-Impact-Analysis.md) and [`Risk-Assessment.md`](PP3-Analysis/Risk-Assessment.md) — the two analysis techniques that define BC requirements |
| **PP4** | Solutions Design | [`Strategies-and-Solutions.md`](PP4-Solutions-Design/Strategies-and-Solutions.md) — how the business will actually meet its continuity requirements |
| **PP5** | Enabling Solutions | [`Response-Structure.md`](PP5-Enabling-Solutions/Response-Structure.md) plus [`Playbooks/`](PP5-Enabling-Solutions/Playbooks/) — operationalising the solutions into real response plans |
| **PP6** | Validation | [`Exercise-and-Testing-Programme.md`](PP6-Validation/Exercise-and-Testing-Programme.md) — proving the plans actually work, not just assuming they do |

## Key Terminology Used

This project uses standard ISO 22301-aligned terminology throughout:
**interested parties** (the preferred term over "stakeholder"), **MTPD**
(Maximum Tolerable Period of Disruption), **RTO** (Recovery Time
Objective), **RPO** (Recovery Point Objective), **MBCO** (Minimum Business
Continuity Objective), **invocation** (declaring BC arrangements active),
and **priority suppliers**.

## Relationship to My Other Work

- [MCP Server / SOC Dashboard](#) — AI-agent tooling for security operations
- [LLM Vulnerability Assessment](#) — OWASP/NIST-aligned AI system risk assessment

Together these represent one consistent thread: applying structured
governance and risk thinking across AI systems, security operations, and
operational resilience.
